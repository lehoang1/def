.. _changelog:

Changelog
=========

.. include:: ../CHANGELOG.rst
